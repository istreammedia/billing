package org.mifosplatform.billing.media.data;

public class MediaassetAttribute {
	
	private final Long id;
	private final String mediaName;

	public MediaassetAttribute(Long mediaId, String mediaName) {

	  this.id=mediaId;
	  this.mediaName=mediaName;
	
	}

}
